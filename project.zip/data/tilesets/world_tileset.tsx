<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="world_tileset" tilewidth="64" tileheight="64" tilecount="156" columns="13">
 <image source="../graphics/tilesets/ground.png" width="850" height="770"/>
</tileset>
